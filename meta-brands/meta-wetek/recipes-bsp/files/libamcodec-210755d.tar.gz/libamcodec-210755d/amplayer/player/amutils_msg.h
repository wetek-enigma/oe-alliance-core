#ifndef __AMUTILS_CMD_
#define __AMUTILS_CMD_

#include "message.h"

int get_amutils_msg(player_cmd_t* cmd);

#endif