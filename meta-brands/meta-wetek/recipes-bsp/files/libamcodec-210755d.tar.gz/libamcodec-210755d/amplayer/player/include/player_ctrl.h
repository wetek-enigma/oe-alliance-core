/*
Just for old code compatible,no this header file may get compare error.
we can add more player controls to here later.
*/
