#ifdef  PLAYER_CACHE_MGT__
#define PLAYER_CACHE_MGT__

int cache_system_init(int enable, const char*dir, int max_size, int block_size);


#endif

