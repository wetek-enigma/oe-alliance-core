#ifndef _PLAYER_TS_H_
#define _PLAYER_TS_H_

int ts_register_stream_decoder(void);

#endif
