#ifndef _PLAYER_ES_H_
#define _PLAYER_ES_H_

int es_register_stream_decoder(void);

#endif
