#ifndef __NSC_HEADER
#define __NSC_HEADER
int is_nsc_file(AVIOContext *pb,const char *name);
#endif
