
#ifndef __MMSH_HEADER
#define __MMSH_HEADER
int is_mmsh_file(AVIOContext *pb,const char *name);
#endif

